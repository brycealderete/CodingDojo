using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RazorFun.Controllers
{
    public class HomeController :Controller
    {
        [HttpGet("")]
        public ViewResult Index(string contact)
        {
            return View();
        }
    }
}