﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;
        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            ViewBag.LeagueOtherThanFootball = context.Leagues
            .Where(l => !l.Sport.Contains("Football"));
            ViewBag.Conference = context.Leagues
                .Where(League => League.Name.Contains("Conference"));
            ViewBag.Atlantic = context.Leagues
                .Where(League => League.Name.Contains("Atlantic"));
            ViewBag.Women = context.Leagues
                .Where(League => League.Name.Contains("Women"));  
            ViewBag.Hockey = context.Leagues
                .Where(League => League.Sport.Contains("Hockey"));  
            ViewBag.Dallas = context.Teams
                .Where(Teams => Teams.Location.Contains("Dallas"));  
            ViewBag.Raptors = context.Teams
                .Where(Teams => Teams.TeamName.Contains("Raptors")); 
            ViewBag.City = context.Teams
                .Where(Teams => Teams.Location.Contains("City")); 
            ViewBag.Start = context.Teams
                .Where(Teams => Teams.TeamName.StartsWith("I"));
            ViewBag.Order = context.Teams
                .Where(t=> t.TeamName.StartsWith("T"));
            ViewBag.Orderlocation = context.Teams
                .OrderBy(t=>t.Location);
            ViewBag.Teamname = context.Teams
                .OrderByDescending(t=>t.TeamName);
            ViewBag.Cooper = context.Players
                .Where(Players=>Players.LastName.Contains("Cooper"));
            ViewBag.notJosh = context.Players
                .Where(Players=>Players.LastName.Contains("Cooper")&& Players.FirstName != ("Joshua"));
            ViewBag.Joshua = context.Players
                .Where(Players=>Players.FirstName.Contains("Joshua"));
            ViewBag.Wyatt = context.Players.Where(p => p.FirstName == "Alexander" || p.FirstName == "Wyatt");




            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}
// Thur
// queueUsingTwoStacks
// create enqueue and dequeue methods on a new queue class that uses ONLY 2 stacks as storage but simulates a FIFO pattern
// sumOfHalvesEqual
// create a method on the array Queue class that returns whether or not the sum of the first half of the queue is equal to the sum of the second half
// DO NOT manually index the queue items, only use the provided queue methods, use no additional arrays or objects for storage
// restore the queue to it's original state before returning