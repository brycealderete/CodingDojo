﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExamProject.Migrations
{
    public partial class fixedfuckup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserGoingtoAct_Acts_ActId",
                table: "UserGoingtoAct");

            migrationBuilder.DropForeignKey(
                name: "FK_UserGoingtoAct_Users_UserId",
                table: "UserGoingtoAct");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserGoingtoAct",
                table: "UserGoingtoAct");

            migrationBuilder.RenameTable(
                name: "UserGoingtoAct",
                newName: "UsersgoingtoActs");

            migrationBuilder.RenameIndex(
                name: "IX_UserGoingtoAct_UserId",
                table: "UsersgoingtoActs",
                newName: "IX_UsersgoingtoActs_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_UserGoingtoAct_ActId",
                table: "UsersgoingtoActs",
                newName: "IX_UsersgoingtoActs_ActId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UsersgoingtoActs",
                table: "UsersgoingtoActs",
                column: "UserGoingtoActId");

            migrationBuilder.AddForeignKey(
                name: "FK_UsersgoingtoActs_Acts_ActId",
                table: "UsersgoingtoActs",
                column: "ActId",
                principalTable: "Acts",
                principalColumn: "ActId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UsersgoingtoActs_Users_UserId",
                table: "UsersgoingtoActs",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UsersgoingtoActs_Acts_ActId",
                table: "UsersgoingtoActs");

            migrationBuilder.DropForeignKey(
                name: "FK_UsersgoingtoActs_Users_UserId",
                table: "UsersgoingtoActs");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UsersgoingtoActs",
                table: "UsersgoingtoActs");

            migrationBuilder.RenameTable(
                name: "UsersgoingtoActs",
                newName: "UserGoingtoAct");

            migrationBuilder.RenameIndex(
                name: "IX_UsersgoingtoActs_UserId",
                table: "UserGoingtoAct",
                newName: "IX_UserGoingtoAct_UserId");

            migrationBuilder.RenameIndex(
                name: "IX_UsersgoingtoActs_ActId",
                table: "UserGoingtoAct",
                newName: "IX_UserGoingtoAct_ActId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserGoingtoAct",
                table: "UserGoingtoAct",
                column: "UserGoingtoActId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserGoingtoAct_Acts_ActId",
                table: "UserGoingtoAct",
                column: "ActId",
                principalTable: "Acts",
                principalColumn: "ActId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserGoingtoAct_Users_UserId",
                table: "UserGoingtoAct",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
