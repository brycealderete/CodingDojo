using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExamProject.Models
{
    public class Act
    {
        [Key]
        public int ActId{get;set;}
        [Required]
        public string Name {get;set;}
        [NotMapped]
        public DateTime Time{get;set;}
        public DateTime Date {get;set;}
        public int Duration{get;set;}
        public string DurationClassification{get; set;}
        public string Description{get;set;}
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        public int UserId{get;set;}
        public User User{get;set;}

        public List<UserGoingtoAct> UsersgoingtoActs {get;set;}

    }
}