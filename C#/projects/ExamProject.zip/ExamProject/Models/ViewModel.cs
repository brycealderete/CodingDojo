using System.Collections.Generic;


namespace ExamProject.Models
{
    public class ViewModel
    {
        
        public User User{get;set;}
        public List<User> Users {get;set;}
        public LoginUser LoginUser{get;set;}
        public Act Act {get;set;}
        
        public List<Act> Acts {get;set;}
        public UserGoingtoAct UserGoingtoAct {get;set;}
        public List<UserGoingtoAct> UsersgoingtoActs {get;set;}
    }
}