using System;
using System.ComponentModel.DataAnnotations;

namespace ExamProject.Models
{
    public class UserGoingtoAct
    {
        [Key]
        public int UserGoingtoActId{get;set;}
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        public int UserId{get;set;}
        public int ActId{get;set;}

        public User User{get;set;}
        public Act Act{get;set;}
    }
}