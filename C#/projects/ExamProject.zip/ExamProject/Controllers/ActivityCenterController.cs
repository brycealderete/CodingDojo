using System;
using System.Linq;
using ExamProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamProject.Controllers
{
    public class ActivityCenterController : Controller
    {
        private ExamProjectContext db;
        public ActivityCenterController(Models.ExamProjectContext context)
        {
            db = context;
        }
        private int? uid
        {
            get
            {
                return HttpContext.Session.GetInt32("UserId");
            }
        }

        private bool isLoggedIn
        {
            get
            {
                return uid != null;
            }
        }

        [HttpGet("ActivityCenter")]
        public IActionResult ActivityCenter()
        {
            if(isLoggedIn)
            {
                ViewModel newView = new ViewModel();
                newView.User=db.Users
            .Include(users=>users.Acts)
            .ThenInclude(w=>w.UsersgoingtoActs)
            .ThenInclude(ug=>ug.Act)
            .Include(User=>User.UsersgoingtoActs)
            .ThenInclude(use=>use.Act)
            .FirstOrDefault(u=>u.UserId==uid);
            
            newView.Acts=db.Acts
            .Include(w=>w.UsersgoingtoActs)
            .ThenInclude(ug=>ug.Act)
            .Include(w=>w.User)
            .ToList();


                return View("ActivityCenter",newView);
            }
            return View("Index");
        }

        [HttpGet("AddAct")]
        public IActionResult AddAct()
            {
                ViewModel newView= new ViewModel();
                newView.User=db.Users.FirstOrDefault(u=>u.UserId==uid);
                return View("CreateAct",newView);
            }


            [HttpPost("CreateAct")]
            public IActionResult CreateAct(Act act)
            {

                var date = act.Date.Date;
                DateTime thisdate =date.Date.Add(act.Time.TimeOfDay);

                


                Act newact=new Act();

                newact.Name=act.Name;
                newact.Date=thisdate;
                newact.Duration=act.Duration;
                newact.DurationClassification=act.DurationClassification;
                newact.Description=act.Description;
                newact.UserId=act.UserId;

                DateTime Today = DateTime.Now;
            
            if((DateTime)thisdate<Today )
            {
                ModelState.AddModelError("Act.Date", "Date must be in the Future");

                ViewModel newview= new ViewModel();
                newview.User=db.Users.FirstOrDefault(u=>u.UserId==uid);
                return View("CreateAct",newview);
            }


                if(ModelState.IsValid)
            {
                
                
                db.Acts.Add(newact);
                db.SaveChanges();
                return RedirectToAction("ActivityCenter");
            }
            ViewModel newView= new ViewModel();
            newView.User=db.Users.FirstOrDefault(u=>u.UserId==uid);
            return View("CreateAct",newView);

            }
            [HttpPost("Delete/{ActId}")]
            public IActionResult Delete(int ActId)
            {
                Act thisAct=db.Acts.FirstOrDefault(w=>w.ActId == ActId);
                    db.Acts.Remove(thisAct);
                    db.SaveChanges();
                

                return RedirectToAction("ActivityCenter");
            }

            [HttpPost("CreateUsersGoingToActs")]
            public IActionResult CreateUsersGoingToActs(UserGoingtoAct userGoingtoAct)
            {
                if(ModelState.IsValid)
                {
                    User user1=new User();
                    user1=db.Users
                    .Include(u=>u.UsersgoingtoActs)
                    .ThenInclude(ug=>ug.Act)
                    .FirstOrDefault(u=>u.UserId==uid);

                    int actid=userGoingtoAct.ActId;
                    Act act=db.Acts.FirstOrDefault(a=>a.ActId==actid);


                    
                                
                                    
                                    foreach (var item in user1.UsersgoingtoActs)
                                    {
                                        DateTime newDT =item.Act.Date.AddHours(item.Act.Duration);
                                        if (item.Act.DurationClassification == "Hours")
                                        {

                                        
                                        if(item.Act.Date<act.Date && act.Date<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }

                                        if(act.DurationClassification=="Hours")
                                        {
                                        DateTime newDt =act.Date.AddHours(act.Duration);
                                        
                                        
                                        if(item.Act.Date<newDt && newDt<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }
                                }
                                    foreach (var item in user1.UsersgoingtoActs)
                                    {
                                        DateTime newDT =item.Act.Date.AddDays(item.Act.Duration);
                                        if (item.Act.DurationClassification == "Days")
                                        {

                                        
                                        if(item.Act.Date<act.Date && act.Date<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }

                                        if(act.DurationClassification=="Days")
                                        {
                                        DateTime newDt =act.Date.AddDays(act.Duration);
                                        
                                        
                                        if(item.Act.Date<newDt && newDt<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }
                                }
                                    foreach (var item in user1.UsersgoingtoActs)
                                    {
                                        DateTime newDT =item.Act.Date.AddMinutes(item.Act.Duration);
                                        if (item.Act.DurationClassification == "Minutes")
                                        {

                                        
                                        if(item.Act.Date<act.Date && act.Date<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }

                                        if(act.DurationClassification=="Minutes")
                                        {
                                        DateTime newDt =act.Date.AddMinutes(act.Duration);
                                        
                                        
                                        if(item.Act.Date<newDt && newDt<newDT)
                                        {
                                            if(isLoggedIn)
                                                {
                                                    ViewModel newView = new ViewModel();
                                                    newView.User=db.Users
                                                .Include(users=>users.Acts)
                                                .ThenInclude(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(User=>User.UsersgoingtoActs)
                                                .ThenInclude(use=>use.Act)
                                                .FirstOrDefault(u=>u.UserId==uid);

                                                newView.Acts=db.Acts
                                                .Include(w=>w.UsersgoingtoActs)
                                                .ThenInclude(ug=>ug.Act)
                                                .Include(w=>w.User)
                                                .ToList();

                                                    ModelState.AddModelError("UserGoingtoAct.ActId", "Unable to join as you have prior engagements");
                                                    return View("ActivityCenter",newView);
                                                }

                                        }
                                        }
                                }
                
                            
                    db.Add(userGoingtoAct);
                    db.SaveChanges();
                    return RedirectToAction("ActivityCenter");








                    0)
                }
                

                return RedirectToAction("ActivityCenter");
            }

            [HttpPost("DeleteUsersGoingToActs/{actId}")]
            public IActionResult DeleteUsersGoingToActs(int actId)
            {
                User user= db.Users.FirstOrDefault(u=>u.UserId == uid);
                

                UserGoingtoAct act1=db.UsersgoingtoActs.FirstOrDefault(u=>u.ActId==actId && u.UserId==uid);
                
                db.UsersgoingtoActs.Remove(act1);
                    db.SaveChanges();

                return RedirectToAction("ActivityCenter");
            }


            [HttpGet("Act/{ActId}")]
            public IActionResult Act (int actId)
            {

                ViewModel newmodel=new ViewModel();

                Act nAct= db.Acts
                .Include(a=>a.User)
                .FirstOrDefault(act=>act.ActId==actId);
                ViewBag.Current=nAct;


                Act newAct= db.Acts
                .Include(act=>act.User)
                .Include(a=>a.UsersgoingtoActs)
                .FirstOrDefault(w=>w.ActId==actId);
                
                ViewBag.isgoing=db.UsersgoingtoActs.FirstOrDefault(u=>u.ActId==actId && u.UserId==uid);
                newmodel.Act=newAct;
                newmodel.UsersgoingtoActs=db.UsersgoingtoActs.Where(u=>u.ActId==actId)
                .Include(a=>a.User)
                .ToList();
                newmodel.User=db.Users.FirstOrDefault(u=>u.UserId == uid);
                
                                
                

                return View("Act",newmodel);
            }


    }
    
}