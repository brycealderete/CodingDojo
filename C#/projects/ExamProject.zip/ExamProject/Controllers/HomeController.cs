﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using ExamProject.Models;

namespace ExamProject.Controllers
{
    public class HomeController : Controller
    {
        private ExamProjectContext db;
        public HomeController(ExamProjectContext context)
        {
            db = context;
        }
        private int? uid
        {
            get
            {
                return HttpContext.Session.GetInt32("UserId");
            }
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost("CreateUser")]
        public IActionResult CreateUser(User user)
        {
            
            if(ModelState.IsValid)
            {
                if(db.Users.Any(u => u.Email == user.Email))
                {
                    ModelState.AddModelError("User.Email", "Email already in use!");
                    return View("Index");
                }
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                user.Password = Hasher.HashPassword(user, user.Password);
                db.Add(user);
                db.SaveChanges();
                return RedirectToAction("LoginPage");
            }
            return View("Index");
            
        }

        [HttpGet("LoginPage")]
        
            public IActionResult LoginPage()
            {
                return View("Index");
            }
        

        [HttpPost("LogUser")]
        public IActionResult LogUser(ViewModel Form)
        {
            if(ModelState.IsValid)
        {
            LoginUser user = Form.LoginUser;
            var userInDb = db.Users.FirstOrDefault(u => u.Email == user.LoginEmail);


            if(userInDb == null)
            {
                ModelState.AddModelError("LoginUser.LoginEmail", "invalid");
                return View("Index");
            }
            
            var hasher = new PasswordHasher<LoginUser>();
            
            var result = hasher.VerifyHashedPassword(user, userInDb.Password, user.LoginPassword);
            
            if(result == 0)
            {
                ModelState.AddModelError("LoginUser.LoginEmail", "Invalid Email/Password");
                return View("Index");
            }
            else
            {
                HttpContext.Session.SetInt32("UserId", userInDb.UserId);
                return RedirectToAction("ActivityCenter", "ActivityCenter");
            }
        }
            return View("Index");
        }

        [HttpGet("Logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        
    }
}
