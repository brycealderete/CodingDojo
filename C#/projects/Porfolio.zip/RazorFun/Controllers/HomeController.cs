using Microsoft.AspNetCore.Mvc;

namespace RazorFun.Controllers
{
    public class HomeController :Controller
    {
        [Route("")]
        public string Index()
    {
        return "this is my index";
    }
    
        [HttpGet("projects")]
        public string projects()
        {
            return "this is my projects";
        }
        [HttpGet]
        [Route("{contact}")]
        public string Contact(string contact)
        {
            return $"this is my {contact}";
        }
    }
}