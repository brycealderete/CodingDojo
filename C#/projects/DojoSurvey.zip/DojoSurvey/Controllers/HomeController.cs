using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace DojoSurvey.Controllers
{
    public class HomeController: Controller
    {
        

        [HttpGet("")]
        public ViewResult Index()
    {
        ViewBag.locations=new List<string> {"Oakland","Seattle","Orange County","Burbank"};
        ViewBag.language= new List<string>{"C#","Python", "Java","Javascript"};
        return View();
    }
    }
}