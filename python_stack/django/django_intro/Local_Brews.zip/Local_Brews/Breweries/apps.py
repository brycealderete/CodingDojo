from django.apps import AppConfig


class BreweriesConfig(AppConfig):
    name = 'Breweries'
