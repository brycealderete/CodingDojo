from django.apps import AppConfig


class TodayConfig(AppConfig):
    name = 'today'
